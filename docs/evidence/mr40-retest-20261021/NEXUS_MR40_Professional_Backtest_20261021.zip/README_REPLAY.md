# Fixed MR40 research replay
One frozen strategy: BTCUSDT Spot, 4h, lookback 40, entry z -2, exit z 0.
Capital: 10,000 USDT per cohort. See the Persian report for initialization,
execution costs, forced exits, limitations, and all results.

This is a completed historical research study, not a trading program.
No private credentials, order placement, automatic promotion, or scheduling.

## Replay
Extract this archive into a NEW directory, install requirements-study.txt in
an isolated Python environment, then run:
    python -m unittest discover -s tests -p test_nexus_mean_reversion_40_m2_retest_v1.py -v
    python research/run_mean_reversion_40_m2_retest_v1.py --root . --source-sha b08d7916581ea98ee44aba222255c643e6873afe --prereg-sha 653a1d4a82d084f4a4c17460e884a41685dafbe7

The supplied prepared_inputs.json is exact-digest pinned. No network is used.
recorded_results/ retains the accepted reference outputs; a replay creates
results/. Existing results are never overwritten. Compare CSV hashes and
numeric results. Run UTC, host, and the enclosing result digest may differ.

The manifest preregisters six cohorts, three cost profiles, and one latency
diagnostic. It does not claim 24 statistically independent samples.
The first-open warm-state rule differs explicitly from the cold July control.
All five continuous August/September exits were signal-driven, with no
terminal liquidation. The 42-month retrospective history is not pristine OOS.

Raw archives are not included. Preparation can be re-run separately using
the original digest-pinned Parquet plus the two cached official Spot gzip
archives and research/prepare_mean_reversion_40_m2_retest_v1.py. Byte SHA256,
capture receipts, source row counts, semantic checks and exact bar inputs are
included. The July original workbook frame identity remains unresolved.

# MR40 adaptive sizing replay

Extract this ZIP, then run `python verify_replay.py` with Python 3.12+. No network or external packages required. It verifies hashes, 42 tests, all 594 ledgers, 66 prefix checks and 36 original-control parity comparisons.

The training-selected volatility target did not pass evaluation. No Paper or Live changes. All history was previously observed. Original exchange trade archives are not duplicated; input frames preserve their provenance and hashes.

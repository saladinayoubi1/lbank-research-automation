# MR40 RR and sizing evidence

Extract the ZIP, then run `python verify_replay.py` with Python 3.12+. No network or external packages are needed for replay. The full study takes about a minute on the reference machine.

27 retrospective paths; 1,728 primary and 3 diagnostic runs. Selection retained the original system. No Live or Paper changes. Intrabar event timestamps are intervals.

The Persian report and summary.json describe assumptions and limitations. This bundle contains validated input frames, not all original exchange trade gzip archives; provenance and their hashes remain in the input records.
